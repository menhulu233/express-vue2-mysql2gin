// 系统常量
// author xiaoRui

package constant

const (
	ContextKeyUserObj ="authedUserObj"
	LOGIN_CODE = "login_code:"
)
